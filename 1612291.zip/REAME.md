# Quản lý thiết bị điện tử

> Kỹ thuật: 3-layers 3-tiers<br>MySQL (db4free.net)<br>Winform C#, Web App ASP .NET

## techstore (End-user)

- Khởi tạo UI
- Nhận data, giao tiếp với người dùng

repos: https://github.com/ngankhanh98/techstore

## techstoreBUS

- Xử lý nghiệp vụ (đơn giản nên không có gì đặt biệt ở đây)

repos: https://github.com/ngankhanh98/techstoreBUS

## techstoreWS

- DAO, DTO

repos: https://github.com/ngankhanh98/techstoreWS

<hr>

_Nguyễn Thị Ngân Khánh, 1612291_
