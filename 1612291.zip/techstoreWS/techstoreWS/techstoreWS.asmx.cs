﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using techstore.DAO;
using techstore.DTO;
using MySql.Data.MySqlClient;


namespace techstoreWS
{
    /// <summary>
    /// Summary description for techstoreWS
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class techstoreWS : System.Web.Services.WebService
    {

        //[WebMethod]
        //public string HelloWorld()
        //{
        //    return "Hello World";
        //}
        ProductDAO productDAO = new ProductDAO();

        [WebMethod]
        public DataSet OnLoad()
        {
            DataSet set = new DataSet();
            set.Tables.Add(productDAO.OnLoad());
            return set;
        }

        [WebMethod]
        public int OnUpdate(Product product)
        {
            return productDAO.OnUpdate(product);
        }

        [WebMethod]
        public int OnInsert(Product product)
        {
            return productDAO.OnInsert(product);
        }

        [WebMethod]
        public int OnDelete(Product product)
        {
            return productDAO.OnDelete(product);
        }
    }
}
